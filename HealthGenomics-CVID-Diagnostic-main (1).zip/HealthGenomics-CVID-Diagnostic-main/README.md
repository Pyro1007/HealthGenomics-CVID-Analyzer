# HealthGenomics-CVID-Diagnostic
CVID is a primary immunodeficiency disorder characterized by:

Low levels of immunoglobulins (antibodies)

Poor antibody response

Increased susceptibility to infections
